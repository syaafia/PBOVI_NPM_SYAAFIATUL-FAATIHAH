from datetime import datetime, timedelta
from prettytable import PrettyTable
from textwrap import fill

class PerpusItem:
    def __init__(self, judul, subjek, stok):
        self.__judul = judul
        self.__subjek = subjek
        self.__stok = stok
        self.__status_pinjam = False
        self.__tanggal_pinjam = None
        self.__tanggal_kembali = None

    def info(self):
        status = "Dipinjam" if self.__status_pinjam else "Tersedia"
        info_tanggal_kembali = (
            f"{self.__tanggal_kembali.strftime('%Y-%m-%d')}"
            if self.__tanggal_kembali
            else "Belum dikembalikan"
        )
        return (
            f"Info buku = {self.__judul}, {self.__subjek}, Stok: {self.__stok}, "
            f"Status: {status}, Tanggal Kembali: {info_tanggal_kembali}"
        )

    def tambah_stok(self, jumlah):
        self.__stok += jumlah

    def kurang_stok(self, jumlah):
        if self.__stok - jumlah >= 0:
            self.__stok -= jumlah
        else:
            print("Stok tidak mencukupi untuk pengurangan")

    def ambil_judul(self):
        return self.__judul

    def ambil_status_pinjam(self):
        return self.__status_pinjam

    def pinjam(self):
        if not self.__status_pinjam and self.__stok > 0:
            print(f"Buku '{self.ambil_judul()}' berhasil dipinjam")
            self.__status_pinjam = True
            self.__tanggal_pinjam = datetime.now()

            while True:
                try:
                    tanggal_kembali_str = input("Masukkan tanggal kembali (YYYY-MM-DD): ")
                    self.__tanggal_kembali = datetime.strptime(tanggal_kembali_str, "%Y-%m-%d")
                    break  # Keluar dari loop jika tanggal valid
                except ValueError:
                    print("Format tanggal tidak valid. Gunakan format YYYY-MM-DD.")

            self.kurang_stok(1)
        elif self.__status_pinjam:
            print(f"Buku '{self.ambil_judul()}' sudah dipinjam")
        else:
            print(f"Stok untuk '{self.ambil_judul()}' habis")

    def kembalikan(self):
        if self.__status_pinjam:
            print(f"Buku '{self.ambil_judul()}' berhasil dikembalikan")
            self.__status_pinjam = False
            self.__tanggal_kembali = None
            self.tambah_stok(1)
        else:
            print(f"Buku '{self.ambil_judul()}' tidak sedang dipinjam")

class Buku(PerpusItem):
    def __init__(self, judul, subjek, ISBN, pengarang, jmlHal, ukuran, stok):
        super().__init__(judul, subjek, stok)
        self.ISBN = ISBN
        self.pengarang = pengarang
        self.jmlHal = jmlHal
        self.ukuran = ukuran

    def deskripsi_buku(self):
        deskripsi = (
            f"ISBN: {self.ISBN}, Pengarang: {self.pengarang}, "
            f"Jumlah Halaman: {self.jmlHal}, Ukuran: {self.ukuran}"
        )
        return textwrap.fill(deskripsi, width=50)

class Majalah(PerpusItem):
    def __init__(self, judul, subjek, volume, issue, stok):
        super().__init__(judul, subjek, stok)
        self.volume = volume
        self.issue = issue

    def deskripsi_majalah(self):
        deskripsi = f"Volume: {self.volume}, Issue: {self.issue}"
        return textwrap.fill(deskripsi, width=50)

class MajalahAnak(Majalah):
    def __init__(self, judul, subjek, volume, issue, kategori, stok):
        super().__init__(judul, subjek, volume, issue, stok)
        self.kategori = kategori

    def deskripsi_majalah_anak(self):
        deskripsi = f"Volume: {self.volume}, Issue: {self.issue}, Kategori: {self.kategori}"
        return textwrap.fill(deskripsi, width=50)

class Katalog:
    def __init__(self):
        self.__daftar_perpus_item = []
        self.__daftar_dipinjam = []

    def tambah_item(self, perpus_item):
        self.__daftar_perpus_item.append(perpus_item)

    def cari(self, judul):
        judul_lower = judul.lower()
        ditemukan = []

        for item in self.__daftar_perpus_item:
            if judul_lower in item.ambil_judul().lower():
                ditemukan.append(item)

        return ditemukan

    def pinjam(self, perpus_item):
        perpus_item.pinjam()
        if perpus_item.ambil_status_pinjam():
            self.__daftar_dipinjam.append(perpus_item)

    def kembalikan(self, perpus_item):
        perpus_item.kembalikan()
        if not perpus_item.ambil_status_pinjam() and perpus_item in self.__daftar_dipinjam:
            self.__daftar_dipinjam.remove(perpus_item)

    def ambil_daftar_item(self):
        return self.__daftar_perpus_item

    def ambil_daftar_dipinjam(self):
        return self.__daftar_dipinjam

    def tampilkan_katalog(self, items=None, dipinjam=False):
        items_to_display = items if items else self.__daftar_perpus_item

        if not items_to_display:
            return "Tidak ada data di katalog"

        if dipinjam:
            items_to_display = [item for item in items_to_display if item.ambil_status_pinjam()]

        judul_set = set()  # Membuat set untuk menyimpan judul buku yang sudah ditampilkan
        table = PrettyTable()
        table.field_names = ["Judul", "Subjek", "Status", "Tanggal Kembali", "Deskripsi", "Stok", "Kategori"]

        for item in items_to_display:
            status = "Dipinjam" if item.ambil_status_pinjam() else "Tersedia"
            if item.ambil_status_pinjam():
                tanggal_kembali = (
                    item._PerpusItem__tanggal_kembali.strftime("%Y-%m-%d")
                    if item._PerpusItem__tanggal_kembali
                    else "Belum dikembalikan"
                )
            else:
                tanggal_kembali = ""
                
            stok = item._PerpusItem__stok
            kategori = getattr(item, 'kategori', '')  # Mengambil atribut 'kategori' jika ada

            deskripsi = ""
            if isinstance(item, Buku):
                deskripsi += f"ISBN: {item.ISBN}\n"
                deskripsi += f"Pengarang: {item.pengarang}\n"
                deskripsi += f"Jumlah Halaman: {item.jmlHal}\n"
                deskripsi += f"Ukuran: {item.ukuran}\n"
            elif isinstance(item, Majalah):
                deskripsi += f"Volume: {item.volume}\n"
                deskripsi += f"Issue: {item.issue}\n"
            elif isinstance(item, MajalahAnak):
                deskripsi += f"Volume: {item.volume}\n"
                deskripsi += f"Issue: {item.issue}\n"
                deskripsi += f"Kategori: {item.kategori}\n"

            # Wrap deskripsi dengan lebar maksimum 50 karakter
            deskripsi = fill(deskripsi, width=50)

            # Menambahkan buku ke tabel hanya jika judulnya belum ditampilkan sebelumnya
            if item.ambil_judul() not in judul_set:
                table.add_row([item.ambil_judul(), item._PerpusItem__subjek, status, tanggal_kembali, deskripsi, stok, kategori])
                judul_set.add(item.ambil_judul())

        return str(table)

def main():
    katalog = Katalog()

    buku1 = Buku("HTML and CSS: Design and Build Websites", "Programming", "11-092-65-99", "Jon Duckett", "30 Halaman", "20 x 8 (cm)", 5)
    buku2 = Buku("Hukum Pidana Internasional", "Hukum", "12-099-99-77", "Dr. Diajeng Wulan Christianti, S.H., LL.M.", "25 Halaman", "27 x 10 (cm)", 8)
    majalah1 = Majalah("Trendi Fashion Magazine designed", "Fashion", "2022-1", "33", 10)
    majalah_anak1 = MajalahAnak("Majalah Anak Edukasi", "Pendidikan", "2022-2", "44", "Edukasi", 15)

    katalog.tambah_item(buku1)
    katalog.tambah_item(buku2)
    katalog.tambah_item(majalah1)
    katalog.tambah_item(majalah_anak1)

    while True:
        print("=" * 50)
        print("              KATALOG PERPUSTAKAAN              ")
        print("=" * 50)
        print("\nMENU>>>>")
        print("1. Tampilkan Katalog")
        print("2. Cari dalam Katalog")
        print("3. Pinjam Buku/Majalah")
        print("4. Kembalikan Buku/Majalah")
        print("5. Daftar Buku yang Dipinjam")
        print("6. Keluar")
        pilihan = input("Masukkan menu pilihan = ")

        if pilihan == "1":
            print(katalog.tampilkan_katalog())

        elif pilihan == "2":
            judul_cari = input("Masukkan judul buku atau majalah yang ingin dicari: ")
            ditemukan = katalog.cari(judul_cari)

            if not ditemukan:
                print(f"Tidak menemukan buku atau majalah dengan judul '{judul_cari}' dalam katalog")
            else:
                print(katalog.tampilkan_katalog(ditemukan))

        elif pilihan == "3":
            judul_pinjam = input("Masukkan judul buku atau majalah yang ingin dipinjam: ")
            ditemukan = katalog.cari(judul_pinjam)

            if not ditemukan:
                print(f"Tidak menemukan buku atau majalah dengan judul '{judul_pinjam}' dalam katalog")
            else:
                katalog.pinjam(ditemukan[0])
                print("Item berhasil dipinjam")

        elif pilihan == "4":
            judul_kembali = input("Masukkan judul buku atau majalah yang ingin dikembalikan: ")
            ditemukan = katalog.cari(judul_kembali)

            if not ditemukan:
                print(f"Tidak menemukan buku atau majalah dengan judul '{judul_kembali}' dalam katalog")
            else:
                katalog.kembalikan(ditemukan[0])
                print("Item berhasil dikembalikan")

        elif pilihan == "5":
            print("Daftar Buku yang Dipinjam:")
            daftar_dipinjam = katalog.ambil_daftar_dipinjam()
            print(katalog.tampilkan_katalog(items=daftar_dipinjam, dipinjam=True))

        elif pilihan == "6":
            break

if __name__ == "__main__":
    main()
