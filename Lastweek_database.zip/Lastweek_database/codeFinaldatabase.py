from datetime import datetime, timedelta
from prettytable import PrettyTable
from textwrap import fill
import mysql.connector

class PerpusItem:
    def __init__(self, judul, subjek, stok):
        self.__judul = judul
        self.__subjek = subjek
        self.__stok = stok
        self.__status_pinjam = False

    def info(self):
        status = "Dipinjam" if self.__status_pinjam else "Tersedia"
        return (
            f"Info item = {self.__judul}, {self.__subjek}, Stok: {self.__stok}, "
            f"Status: {status}"
        )

    def tambah_stok(self, jumlah):
        self.__stok += jumlah

    def kurang_stok(self, jumlah):
        if self.__stok - jumlah >= 0:
            self.__stok -= jumlah
        else:
            print("Stok tidak mencukupi untuk pengurangan")

    def ambil_judul(self):
        return self.__judul

    def ambil_status_pinjam(self):
        return self.__status_pinjam

    def pinjam(self):
        if not self.__status_pinjam and self.__stok > 0:
            print(f"Buku '{self.ambil_judul()}' berhasil dipinjam")
            self.__status_pinjam = True
            self.kurang_stok(1)
        elif self.__status_pinjam:
            print(f"Buku '{self.ambil_judul()}' sudah dipinjam")
        else:
            print(f"Stok untuk '{self.ambil_judul()}' habis")

    def kembalikan(self):
        if self.__status_pinjam:
            print(f"Buku '{self.ambil_judul()}' berhasil dikembalikan")
            self.__status_pinjam = False
            self.tambah_stok(1)
        else:
            print(f"Buku '{self.ambil_judul()}' tidak sedang dipinjam")

class Buku(PerpusItem):
    def __init__(self, judul, subjek, ISBN, pengarang, jmlHal, ukuran, stok):
        super().__init__(judul, subjek, stok)
        self.ISBN = ISBN
        self.pengarang = pengarang
        self.jmlHal = jmlHal
        self.ukuran = ukuran

    def deskripsi_buku(self):
        deskripsi = (
            f"ISBN: {self.ISBN}, Pengarang: {self.pengarang}, "
            f"Jumlah Halaman: {self.jmlHal}, Ukuran: {self.ukuran}"
        )
        return fill(deskripsi, width=50)
    
    def info(self):
        return f"{super().info()}, {self.deskripsi_buku()}"


class Majalah(PerpusItem):
    def __init__(self, judul, subjek, volume, issue, stok):
        super().__init__(judul, subjek, stok)
        self.volume = volume
        self.issue = issue

    def deskripsi_majalah(self):
        deskripsi = f"Volume: {self.volume}, Issue: {self.issue}"
        return fill(deskripsi, width=50)
    
    def info(self):
        return f"{super().info()}, {self.deskripsi_majalah()}"


class MajalahAnak(Majalah):
    def __init__(self, judul, subjek, volume, issue, kategori, stok):
        super().__init__(judul, subjek, volume, issue, stok)
        self.kategori = kategori

    def deskripsi_majalah_anak(self):
        deskripsi = f"Volume: {self.volume}, Issue: {self.issue}, Kategori: {self.kategori}"
        return fill(deskripsi, width=50)
    
    def info(self):
        return f"{super().info()}, {self.deskripsi_majalah_anak()}"


class Katalog:
    def __init__(self):
        self.db_connection = mysql.connector.connect(
            host='localhost',
            user='root',
            password='',
            database='5220411175'
        )
        self.create_database()
        
        self._Katalog__daftar_perpus_item = []
        self._Katalog__daftar_dipinjam = []

    def create_database(self):
        try:
            with self.db_connection.cursor() as cursor:
                cursor.execute('''
                    CREATE TABLE IF NOT EXISTS perpus_item (
                        judul VARCHAR(255) PRIMARY KEY,
                        subjek VARCHAR(255),
                        stok INT,
                        status_pinjam INT,
                        isbn VARCHAR(20),
                        volume VARCHAR(20),
                        ukuran VARCHAR(20),
                        kategori VARCHAR(50)
                    )
                ''')
        except mysql.connector.Error as err:
            print(f"Kesalahan saat inisialisasi database: {err}")

    def tambah_item(self, perpus_item):
        try:
            with self.db_connection.cursor() as cursor:
                query = '''
                    INSERT INTO perpus_item (judul, subjek, stok, status_pinjam, isbn, volume, ukuran, kategori) 
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                '''
                values = (
                    perpus_item.ambil_judul(), 
                    perpus_item._PerpusItem__subjek, 
                    perpus_item._PerpusItem__stok, 
                    0,  # status_pinjam default 0 (Tersedia)
                    getattr(perpus_item, 'ISBN', None),  # ISBN untuk Buku
                    getattr(perpus_item, 'volume', None),  # volume untuk Majalah dan MajalahAnak
                    getattr(perpus_item, 'ukuran', None),  # ukuran untuk Buku
                    getattr(perpus_item, 'kategori', None)  # kategori untuk MajalahAnak
                )
                cursor.execute(query, values)
            self.db_connection.commit()
            print(f"Item '{perpus_item.ambil_judul()}' berhasil ditambahkan ke katalog")
            
        except mysql.connector.Error as err:
            print(f"Kesalahan saat menambah item: {err}")

    def hapus_item(self, perpus_item):
        try:
            with self.db_connection.cursor() as cursor:
                query = 'DELETE FROM perpus_item WHERE judul = %s'
                cursor.execute(query, (perpus_item.ambil_judul(),))
            self.db_connection.commit()
            print(f"Item '{perpus_item.ambil_judul()}' berhasil dihapus dari katalog")
        except mysql.connector.Error as err:
            print(f"Kesalahan saat menghapus item: {err}")

    def edit_item(self, perpus_item, new_stok):
        try:
            with self.db_connection.cursor() as cursor:
                query = 'UPDATE perpus_item SET stok = %s WHERE judul = %s'
                cursor.execute(query, (new_stok, perpus_item.ambil_judul()))
            self.db_connection.commit()
            print(f"Stok item '{perpus_item.ambil_judul()}' berhasil diubah menjadi {new_stok}")
        except mysql.connector.Error as err:
            print(f"Kesalahan saat mengedit item: {err}")

    def cari(self, judul):
        judul_lower = judul.lower()
        ditemukan = []

        with self.db_connection.cursor() as cursor:
            cursor.execute('SELECT * FROM perpus_item WHERE LOWER(judul) LIKE %s', ('%' + judul_lower + '%',))
            result = cursor.fetchall()

            for row in result:
                if judul_lower in row[0].lower():
                    ditemukan.append(PerpusItem(row[0], row[1], row[2]))

        return ditemukan

    def ambil_daftar_dipinjam(self):
        return self._daftar_dipinjam

    def pinjam(self, perpus_item):
        perpus_item.pinjam()
        if perpus_item.ambil_status_pinjam():
            self.ambil_daftar_dipinjam().append(perpus_item)

    def kembalikan(self, perpus_item):
        perpus_item.kembalikan()
        if not perpus_item.ambil_status_pinjam() and perpus_item in self.ambil_daftar_dipinjam():
            self.ambil_daftar_dipinjam().remove(perpus_item)

    def tampilkan_katalog(self):
        with self.db_connection.cursor() as cursor:
            cursor.execute('SELECT * FROM perpus_item')
            result = cursor.fetchall()

            if not result:
                return "Katalog kosong"

            table = PrettyTable()
            table.field_names = ["Judul", "Subjek", "Stok", "Status Pinjam"]

            for row in result:
                table.add_row([row[0], row[1], row[2], "Dipinjam" if row[3] else "Tersedia"])

        return str(table)

def main():
    katalog = Katalog()

    while True:
        print("=" * 50)
        print("              KATALOG PERPUSTAKAAN              ")
        print("=" * 50)
        print("\n>>>Menu:")
        print("1. Tampilkan Katalog")
        print("2. Cari Item")
        print("3. Tambah Item ke Katalog")
        print("4. Hapus Item dari Katalog")
        print("5. Edit Stok Item")
        print("0. Keluar")

        pilihan = input("Masukkan pilihan (1-9): ")

        if pilihan == "1":
            print(katalog.tampilkan_katalog())

        elif pilihan == "2":
            judul_cari = input("Masukkan judul yang ingin dicari: ")
            ditemukan = katalog.cari(judul_cari)

            if not ditemukan:
                print(f"Tidak menemukan item dengan judul '{judul_cari}' dalam katalog")
            else:
                for item in ditemukan:
                    print(item.info())

        elif pilihan == "3":
            jenis_item = input("Masukkan jenis item (Buku/Majalah/MajalahAnak): ")

            if jenis_item.lower() == 'buku':
                judul = input("Judul Buku: ")
                subjek = input("Subjek Buku: ")
                stok = int(input("Stok Buku: "))
                isbn = input("ISBN Buku: ")
                pengarang = input("Pengarang Buku: ")
                jml_hal = input("Jumlah Halaman Buku: ")
                ukuran = input("Ukuran Buku: ")

                buku = Buku(judul, subjek, isbn, pengarang, jml_hal, ukuran, stok)
                katalog.tambah_item(buku)

            elif jenis_item.lower() == 'majalah':
                judul = input("Judul Majalah: ")
                subjek = input("Subjek Majalah: ")
                stok = int(input("Stok Majalah: "))
                volume = input("Volume Majalah: ")
                issue = input("Issue Majalah: ")

                majalah = Majalah(judul, subjek, volume, issue, stok)
                katalog.tambah_item(majalah)

            elif jenis_item.lower() == 'majalahanak':
                judul = input("Judul Majalah Anak: ")
                subjek = input("Subjek Majalah Anak: ")
                stok = int(input("Stok Majalah Anak: "))
                volume = input("Volume Majalah Anak: ")
                issue = input("Issue Majalah Anak: ")
                kategori = input("Kategori Majalah Anak: ")

                majalah_anak = MajalahAnak(judul, subjek, volume, issue, kategori, stok)
                katalog.tambah_item(majalah_anak)

            else:
                print("Jenis item tidak valid.")

        elif pilihan == "4":
            judul_hapus = input("Masukkan judul buku atau majalah yang ingin dihapus: ")
            ditemukan = katalog.cari(judul_hapus)

            if not ditemukan:
                print(f"Tidak menemukan buku atau majalah dengan judul '{judul_hapus}' dalam katalog")
            else:
                katalog.hapus_item(ditemukan[0])

        elif pilihan == "5":
            judul_edit = input("Masukkan judul buku atau majalah yang ingin diubah stoknya: ")
            ditemukan = katalog.cari(judul_edit)

            if not ditemukan:
                print(f"Tidak menemukan buku atau majalah dengan judul '{judul_edit}' dalam katalog")
            else:
                new_stok = int(input("Masukkan stok baru: "))
                katalog.edit_item(ditemukan[0], new_stok)

        elif pilihan == "0":
            print("Keluar dari program.")
            break

        else:
            print("Pilihan tidak valid. Silakan masukkan nomor menu yang benar.")

if __name__ == "__main__":
    main()