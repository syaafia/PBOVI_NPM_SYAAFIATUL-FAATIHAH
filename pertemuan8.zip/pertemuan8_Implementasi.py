class Katalog:
    def __init__(self):
        self.daftar_buku = []

    def tambah_buku(self, buku):
        self.daftar_buku.append(buku)

    def cari(self, judul):
        judul_lower = judul.lower()
        ditemukan = []

        for item in self.daftar_buku:
            if judul_lower in item.judul.lower() and isinstance(item, (Buku, Majalah, DVD)):
                ditemukan.append(item)

        return ditemukan

    def get_daftar_buku(self):
        return self.daftar_buku
        
class PerpusItem :
    def __init__(self, judul, subjek) :
        self.judul = judul
        self.subjek = subjek

    def LokasiPenyimpanan(self) :
        print("lokasi simpan")
        
    def info(self) :
        print("info buku = {self.judul}, {self.subjek}")
        
class Buku(PerpusItem) :
    def __init__(self, judul, subjek, ISBN, pengarangs, jmlHal, ukuran) :
        super().__init__(judul, subjek)
        self.ISBN = ISBN
        self.pengarangs = pengarangs
        self.jmlHal = jmlHal
        self.ukuran = ukuran
        
class Majalah(PerpusItem) :
    def __init__(self, judul, subjek, volume, issue) :
        super().__init__(judul, subjek)
        self.volume = volume
        self.issue = issue
        
class DVD(PerpusItem):
    def __init__(self, judul, subjek, aktor, genre):
        super().__init__(judul, subjek)
        self.aktor = aktor
        self.genre = genre

#ini buat katalog
katalog = Katalog()
buku1 = Buku("HTML and CSS: Design and Build Websites", "Programming", "11-092-65-99", "Jon Duckett", "30 Halaman", "20 x 8 (cm)")
buku2 = Buku("Hukum Pidana Internasional", "Hukum", "12-099-99-77", "Dr. Diajeng Wulan Christianti, S.H., LL.M.", "25 Halaman", "27 x 10 (cm)")
buku3 = Buku("Is It Bad Or Good Habits", "Physicology", "13-088-78-99", "Sabrina Ara", "50 Halaman", "25 x 7 (cm)")
majalah1 = Majalah("Trendi Fashion Magazine designed", "Fashion", "2022-1", "33")
majalah2 = Majalah("COFINA Magazine advertising designed", "Kids", "2021-1", "31")
dvd1 = DVD("The Social Network", "Biografi", "Jesse Eisenberg", "Drama")
dvd2 = DVD("Bad Boys", "Comedy", "Martin Lawrence", "Action")

katalog.tambah_buku(buku1)
katalog.tambah_buku(buku2)
katalog.tambah_buku(buku3)
katalog.tambah_buku(majalah1)
katalog.tambah_buku(majalah2)
katalog.tambah_buku(dvd1)
katalog.tambah_buku(dvd2)

def main() :
    while True:
        print("="*30)
        print("      PERPUSNAS INDONESIA   ")
        print("="*30)
        print("selamat datang...")
        print("\nMENU>>>>")
        print("1. Cari dalam Katalog")
        print("2. Tampilkan Informasi Buku")
        print("3. Tampilkan Informasi Majalah")
        print("4. Tampilkan Informasi DVD")
        print("5. Keluar")
        pilihan = input("Masukkan menu pilihan = ")
    
        if pilihan == "1":
                judul_cari = input("Masukkan judul buku, majalah, atau DVD yang ingin dicari: ")
                ditemukan = katalog.cari(judul_cari)

                if not ditemukan:
                    print(f"Tidak menemukan buku, majalah, atau DVD dengan judul '{judul_cari}' dalam katalog")
                else:
                    for item in ditemukan:
                        if isinstance(item, Buku):
                            print(f"Informasi Buku: {item.judul}, {item.subjek}, {item.ISBN}, {item.pengarangs}, {item.jmlHal}, {item.ukuran}")
                        elif isinstance(item, Majalah):
                            print(f"Informasi Majalah: {item.judul}, {item.subjek}, {item.volume}, {item.issue}")
                        elif isinstance(item, DVD):
                            print(f"Informasi DVD: {item.judul}, {item.subjek}, {item.aktor}, {item.genre}")
        elif pilihan == "2":
            daftar_buku = katalog.get_daftar_buku()
            for buku in daftar_buku:
                if isinstance(buku, Buku):
                    print(f"Informasi Buku: {buku.judul}, {buku.subjek}, {buku.ISBN}, {buku.pengarangs}, {buku.jmlHal}, {buku.ukuran}")

        elif pilihan == "3":
            for majalah in katalog.get_daftar_buku():
                if isinstance(majalah, Majalah):
                    print(f"Informasi Majalah: {majalah.judul}, {majalah.subjek}, {majalah.volume}, {majalah.issue}")


        elif pilihan == "4":
            daftar_dvd = [item for item in katalog.get_daftar_buku() if isinstance(item, DVD)]
            for dvd in daftar_dvd:
                print(f"Informasi DVD: {dvd.judul}, {dvd.subjek}, {dvd.aktor}, {dvd.genre}")


        elif pilihan == "5":
            print("Terima kasih! Keluar dari program.")
            break
            
        else:
            print("Pilihan tidak valid. Silakan masukkan nomor menu yang benar.")
main()